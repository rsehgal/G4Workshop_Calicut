#ifndef PROGRAM1_MODULARPHYSICSLIST_HH
#define PROGRAM1_MODULARPHYSICSLIST_HH

#include "G4VModularPhysicsList.hh"

class Program1_ModularPhysicsList : public G4VModularPhysicsList {
public:
    Program1_ModularPhysicsList();
    virtual ~Program1_ModularPhysicsList();
};

#endif
