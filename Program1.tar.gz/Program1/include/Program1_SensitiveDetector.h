#ifndef PROGRAM1_SENSITIVEDETECTOR_HH
#define PROGRAM1_SENSITIVEDETECTOR_HH

#include "G4VSensitiveDetector.hh"

class Program1_SensitiveDetector : public G4VSensitiveDetector {
public:
    Program1_SensitiveDetector(const G4String& name);
    virtual ~Program1_SensitiveDetector();

    virtual G4bool ProcessHits(G4Step* step, G4TouchableHistory* history);
};

#endif
