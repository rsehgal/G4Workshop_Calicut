#ifndef PROGRAM1_STEPPINGACTION_HH
#define PROGRAM1_STEPPINGACTION_HH

#include "G4UserSteppingAction.hh"
#include "Program1_EventAction.h"

class Program1_SteppingAction : public G4UserSteppingAction {
Program1_EventAction *eventAction;
public:
    Program1_SteppingAction();
    Program1_SteppingAction(Program1_EventAction *evAction);
    virtual ~Program1_SteppingAction();

    virtual void UserSteppingAction(const G4Step*);
};

#endif
