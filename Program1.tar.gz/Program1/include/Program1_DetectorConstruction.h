#ifndef PROGRAM1_DETECTORCONSTRUCTION_HH
#define PROGRAM1_DETECTORCONSTRUCTION_HH

#include "G4VUserDetectorConstruction.hh"

class Program1_DetectorConstruction : public G4VUserDetectorConstruction {
public:
    Program1_DetectorConstruction();
    virtual ~Program1_DetectorConstruction();

    virtual G4VPhysicalVolume* Construct();
};

#endif
