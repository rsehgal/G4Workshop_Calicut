#ifndef PROGRAM1_RUNACTION_HH
#define PROGRAM1_RUNACTION_HH

class G4Run;

#include "G4UserRunAction.hh"
#include "G4Event.hh"
class Program1_RunAction : public G4UserRunAction {
public:
    Program1_RunAction();
    virtual ~Program1_RunAction();
    virtual void BeginOfRunAction(const G4Run*);
    virtual void EndOfRunAction(const G4Run*);
};

#endif
