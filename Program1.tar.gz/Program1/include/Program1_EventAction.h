#ifndef PROGRAM1_EVENTACTION_HH
#define PROGRAM1_EVENTACTION_HH

#include "G4UserEventAction.hh"
#include "G4Event.hh"
class Program1_EventAction : public G4UserEventAction {
    double eDep;
public:
    Program1_EventAction();
    virtual ~Program1_EventAction();
    virtual void BeginOfEventAction(const G4Event *event);
    virtual void EndOfEventAction(const G4Event *event);
    void AddEnergy(double eval);
};

#endif
