#ifndef PROGRAM1_USERPHYSICSLIST_HH
#define PROGRAM1_USERPHYSICSLIST_HH

#include "G4VUserPhysicsList.hh"

class Program1_UserPhysicsList : public G4VUserPhysicsList {
public:
    Program1_UserPhysicsList();
    virtual ~Program1_UserPhysicsList();
    virtual void ConstructParticle(); 
    virtual void ConstructProcess(); 
};

#endif
