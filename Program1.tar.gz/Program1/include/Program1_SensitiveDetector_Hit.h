#ifndef PROGRAM1_SENSITIVEDETECTOR_HIT_HH
#define PROGRAM1_SENSITIVEDETECTOR_HIT_HH

#include "G4VHit.hh"

class Program1_SensitiveDetector_Hit : public G4VHit {
public:
    Program1_SensitiveDetector_Hit();
    virtual ~Program1_SensitiveDetector_Hit();
};

#endif
