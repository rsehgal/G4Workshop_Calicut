#ifndef PROGRAM1_PRIMARYGENERATORACTION_HH
#define PROGRAM1_PRIMARYGENERATORACTION_HH

#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ParticleGun.hh"

class Program1_PrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction {
public:
    Program1_PrimaryGeneratorAction();
    virtual ~Program1_PrimaryGeneratorAction();

    virtual void GeneratePrimaries(G4Event* anEvent);
public:
    G4ParticleGun *fParticleGun;
};

#endif
