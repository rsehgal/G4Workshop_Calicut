#include "Program1_SteppingAction.h"
#include "G4Step.hh"
#include "G4Track.hh"
#include "G4SystemOfUnits.hh"
#include "G4VProcess.hh"
#include "G4VTouchable.hh"
#include "G4RunManager.hh"
#include "G4UserEventAction.hh"
#include "Program1_EventAction.h"
Program1_SteppingAction::Program1_SteppingAction() {}

Program1_SteppingAction::Program1_SteppingAction(Program1_EventAction *evAction) {

eventAction = evAction;
}

Program1_SteppingAction::~Program1_SteppingAction() {}

void Program1_SteppingAction::UserSteppingAction(const G4Step* step) {
/*
    G4Track* track = step->GetTrack();
    G4double energy = track->GetKineticEnergy();
    G4cout << "Energy: " << energy / MeV << " MeV" << G4endl;
    std::cout << "Energy deposited in step : " << step->GetTotalEnergyDeposit() << std::endl;
    
    //Getting track ID
    int trackId = track->GetTrackID();
    std::cout << "Track ID : " << trackId << std::endl;
    G4String particleName = track->GetDefinition()->GetParticleName();
    std::cout <<"Particle Name : " << particleName << std::endl;
    
    
    //lunch OVER
    if(track->GetCreatorProcess())
    {
    G4String processName = track->GetCreatorProcess()->GetProcessName();
    std::cout << "CREATOR PROCESS NAME : " << processName << std::endl;
}

G4ThreeVector position = track->GetPosition();
std::cout <<"Particle position : " << position << std::endl;
std::cout << "Volume Name : "<< track->GetVolume()->GetName() << std::endl;

const G4VTouchable *touchable = track->GetTouchable();
if(touchable->GetVolume()->GetName()!="World"){
   std::cout << "Volume Name from Touchable : "<< touchable->GetVolume()->GetName() << std::endl;
   std::cout << "Mother Volume Name from Touchable : "<< touchable->GetVolume(1)->GetName() << std::endl;
}

    // TRy to get mother volume name
    //NEXT : Get particle postion 
    //       Get Volume Name
    
    //SOME MORE
    //		Get Logical Volume
    //		
    
    */
    
    eventAction->AddEnergy(step->GetTotalEnergyDeposit());
    
}








