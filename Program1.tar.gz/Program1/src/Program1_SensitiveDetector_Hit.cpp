#include "Program1_SensitiveDetector_Hit.h"

Program1_SensitiveDetector_Hit::Program1_SensitiveDetector_Hit()  {
}

Program1_SensitiveDetector_Hit::~Program1_SensitiveDetector_Hit() {}


