#include "Program1_DetectorConstruction.h"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4NistManager.hh"
#include "Program1_SensitiveDetector.h"
#include "G4SDManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"
Program1_DetectorConstruction::Program1_DetectorConstruction() {}

Program1_DetectorConstruction::~Program1_DetectorConstruction() {}

G4VPhysicalVolume* Program1_DetectorConstruction::Construct() {
    G4NistManager* nist = G4NistManager::Instance();
    G4Material* worldMat = nist->FindOrBuildMaterial("G4_AIR");
G4Material* nai = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
    //Modify the world volume dimension as required
    

G4Box* solidWorld = new G4Box("World", 0.5*m, 0.5*m, 0.5*m);
    G4LogicalVolume* logicWorld = new G4LogicalVolume(solidWorld, worldMat, "World");
    G4VPhysicalVolume* physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false, 0);


G4Tubs* solidNai = new G4Tubs("NaI", 0, 5.7*cm/2 , 5.3*cm/2 , 0, 360*deg);
    G4LogicalVolume* logicNai = new G4LogicalVolume(solidNai, nai, "LogicNai");
    G4VPhysicalVolume* physNai = new G4PVPlacement(nullptr, G4ThreeVector(), logicNai, "PhysicalNai", logicWorld, false, 0,true);
    
    //TODO : Create your desired detectors here
    
    

    // Logic to Attach sensitive detector to a logical volume
    //Program1_SensitiveDetector* detector = new Program1_SensitiveDetector("SensitiveDetector");
    //G4SDManager::GetSDMpointer()->AddNewDetector(detector);
    //logicWorld->SetSensitiveDetector(detector);

    return physWorld;
}
