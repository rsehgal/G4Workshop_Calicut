#include "Program1_RunAction.h"
#include "G4Run.hh"

Program1_RunAction::Program1_RunAction()  {
}

Program1_RunAction::~Program1_RunAction() {}

void Program1_RunAction::BeginOfRunAction(const G4Run*){

}

void Program1_RunAction::EndOfRunAction(const G4Run*){

}

