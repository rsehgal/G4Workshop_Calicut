#include "Program1_EventAction.h"

Program1_EventAction::Program1_EventAction()  {
}

Program1_EventAction::~Program1_EventAction() {}

void Program1_EventAction::BeginOfEventAction(const G4Event *event){
    //TODO : All the required logic you want to do at the start
    //       of each event
    eDep = 0.;
    std::cout  <<"-------------------------------"<<std::endl;
    std::cout << "Hello Raman from BeginOf event action "<<std::endl;
    std::cout << "Event ID : " << event->GetEventID() << std::endl;
}

void Program1_EventAction::EndOfEventAction(const G4Event *event){
    //TODO : All the required logic you want to do at the end
    //       of each event
    std::cout << "Hello Sehgal from End Of event action "<<std::endl;
    std::cout << "Total Energy deposited in event : " << eDep << std::endl;
}

void Program1_EventAction::AddEnergy(double eval){
    	eDep += eval;
    }

