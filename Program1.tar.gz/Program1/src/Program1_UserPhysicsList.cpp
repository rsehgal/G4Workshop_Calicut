#include "Program1_UserPhysicsList.h"

Program1_UserPhysicsList::Program1_UserPhysicsList()  {
}

Program1_UserPhysicsList::~Program1_UserPhysicsList() {}

void Program1_UserPhysicsList::ConstructParticle(){
    //std::cout <<"Construct Particle....." << std::endl;
    
    //TODO : Add the particles Primary and secondary that may be used 
    //       during the simulation
}

void Program1_UserPhysicsList::ConstructProcess(){
    //std::cout <<"Construct Process....." << std::endl;
    
    //TODO : Add all the physics physics processes that is required  
    //       during the simulation
}

